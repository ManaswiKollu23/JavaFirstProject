package com.sapient.shapes;

public class Circle {
	
	void calculateArea(int radius) {
		System.out.println("The Area of the Circe is "+ (3.14*radius*radius));
	}
}
