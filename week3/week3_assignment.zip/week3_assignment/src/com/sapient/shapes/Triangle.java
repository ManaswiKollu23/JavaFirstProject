package com.sapient.shapes;

public class Triangle {

	void calculateArea(int sides) {
		System.out.println("The Area of the Triangle is "+ (0.433*sides*sides));
	}
}
