package com.sapient.shapes;

public class Square {
	
	void calculateArea(int sides) {
		System.out.println("The Area of the Square is "+ (sides*sides));
	}
}
